# Welcome to napari-zelda

ZELDA: a 3D Image Segmentation and Parent to Child relation plugin for microscopy image analysis in napari
