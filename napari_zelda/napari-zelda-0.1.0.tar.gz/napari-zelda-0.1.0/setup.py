from setuptools import setup

use_scm={"write_to": "napari_zelda/_version.py"}

setup(
    version='0.1.0')
