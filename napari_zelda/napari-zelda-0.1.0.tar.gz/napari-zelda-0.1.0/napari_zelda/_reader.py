from napari_plugin_engine import napari_hook_implementation


@napari_hook_implementation
def napari_get_reader():
    pass

def reader_function():
    pass
